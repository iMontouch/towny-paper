<?php
require "config/configuration.php";
?>
<!DOCTYPE html>
<HTML>
<HEAD>
<meta http-equiv="X-UA-Compatible" content="IE=edge;chrome=1" />
<TITLE><?php echo Config::get('title');?></TITLE>
<link rel='stylesheet' type='text/css' href='style/style_<?php echo Config::get('style');?>.css'>
<script type="text/javascript" src="jquery.js"></script>
</HEAD>
<BODY>

<!--
EDITABLE: Navigation
-->
<div id=nav>
<div id=button><a  id="home" class=navlink href="<?php echo Config::get('home');?>">Home</a></div>
<div id=button><a class=navlink href="https://github.com/boy0001/FastAsyncWorldedit/wiki">Wiki</a></div>
<div id=button><a class=navlink href="https://github.com/boy0001/FastAsyncWorldedit/issues">Issues</a></div>
<div id=button><a class=navlink href="http://empcraft.com/assetpack/source.zip">Source</a></div>
</div>
<div id=banner style="height: 270px; margin: auto;">
<iframe width="100%" height="270px" id="my_iframe" style="display:none;"></iframe><br>
</div>
<!--
END NAVIGATION
-->

<?php
echo "<h1>" . Config::get('title') . "</h1>";
?>
<div id="main">
<h2>Select a category</h2>
<div id=categories></div>
<h2>Search for an asset</h2>
<div id=box>
<form id=myform onsubmit="return post()" method="post">
    <input type="hidden" id="hidden" name="method" placeholder="Method..."/>
    <input type="text" id="input" name="id" placeholder="Search..." required/>
    <input type="submit" value="Search">
</form>

<div id=results></div>
<form id=downloadForm onsubmit="return download()" method="post">
    <input id=downloadbutton type="submit" value="Download" hidden=true>
</form>
</div>
<h2>How to create an asset</h2>
<table>
	<tr>
		<td><b>Copy an area to your clipboard</b></td>
		<td id=ip><i>//br copy [size]</i> <b>or</b> <i>//copy</i></td>
	</tr>
	<tr>
		<td><b>Save the asset</b></td>
		<td>//asset &lt;category&gt;</td>
	</tr>
	</table>
</div>
</div>
<br/><br/><br/><br/>
<script type="text/javascript">
// TOP
var files = {};

$.get("list.php", function(data){
    window.json = JSON.parse(data);
    var categories = {};
    var element = document.getElementById("categories");
    for (var i in window.json) {
        var file = window.json[i];
        var split = file.split(new RegExp("\\\\|/", 'g'));
        var name = split[split.length - 1].split(".");
        var path = split.slice(1,split.length - 1).join("/");
        if (path in categories) {
            continue;
        }
        categories[path] = true;
        element.innerHTML += "<div id=download onclick=\"cat('" + path + "');\">" + path + "</div>";
    }
});

function cat(term) {
    document.getElementById("input").value = term;
    post();
}

function download() {
    var data = {'files':JSON.stringify(files)};
    $.post("zip.php", data, function(result) {
        prompt("Assets can be used in brushes e.g.\n//br paste\n//br visualize 2\n//br scroll clipboard [url|folder]", "<?php echo "http://empcraft.com/assetpack/" . 'downloads/' . basename($_SERVER['REMOTE_ADDR']) . '.zip'; ?>");
    });
    return false;
}

function info(data) {
    document.getElementById("results").innerHTML = "<pre>" + JSON.stringify(data) + "</pre>";
}

function toggle(id, file) {
    var element = document.getElementById(id);
    if (id in files) {
        delete files[id];
        element.innerHTML = "Add";
    }
    else {
        files[id] = file;
        element.innerHTML = "Remove";
    }
    initDownload();
}

function initDownload() {
    var size = Object.keys(files).length;
    var element = document.getElementById("downloadbutton");
    if (size == 0) {
        element.hidden = true;
        return;
    }
    element.hidden = false;
    element.value = "Download (" + size + " file" + (size > 1 ? "s" : "") +")";
}

function add() {
    for (var i = 1, row; row = table.rows[i]; i++) {
        var add = row.cells[5];
        files[add.firstChild.id] = table.rows[i].id;
        add.firstChild.innerHTML = "Remove";
    }
    initDownload();
}

function remove() {
    for (var i = 1, row; row = table.rows[i]; i++) {
        var add = row.cells[5];
        delete files[add.firstChild.id]
        add.firstChild.innerHTML = "Add";
    }
    initDownload();
}

function load(link) {
    var iframe = document.getElementById("my_iframe");
    if (iframe.style.display === 'none') {
        var banner = document.getElementById("banner");
        iframe.style = banner.style;
    }                
    iframe.src = link.href;
    return false;
}

function post() {
    var input = document.getElementById("input").value.trim().split(" ");
    var result = document.getElementById("results");
    
    window.search = {};
    window.input = {};
    for (var i in input) {
        var term = input[i];
        if (term.indexOf('!=') > -1) {
            var split = term.split('!=');
            window.input[split[0]] = split[1];
            window.search[split[0]] = function(key, data, input) {
                return data + "" !== input;
            }
        }
        else if (term.indexOf('<=') > -1) {
            var split = term.split('<=');
            window.input[split[0]] = split[1];
            window.search[split[0]] = function(key, data, input) {
                return parseInt(data) <= parseInt(input);
            }
        }
        else if (term.indexOf('>=') > -1) {
            var split = term.split('>=');
            window.input[split[0]] = split[1];
            window.search[split[0]] = function(key, data, input) {
                return parseInt(data) >= parseInt(input);
            }
            window.input
        }
        else if (term.indexOf('>') > -1) {
            var split = term.split('>');
            window.input[split[0]] = split[1];
            window.search[split[0]] = function(key, data, input) {
                return parseInt(data) > parseInt(input);
            }
        }
        else if (term.indexOf('<') > -1) {
            var split = term.split('<');
            window.input[split[0]] = split[1];
            window.search[split[0]] = function(key, data, input) {
                return parseInt(data) < parseInt(input);
            }
        }
        else if (term.indexOf('=') > -1) {
            var split = term.split('=');
            window.input[split[0]] = split[1];
            window.search[split[0]] = function(key, data, input) {
                return data + "" === input;
            }
        }
        else if (term.indexOf(':') > -1) {
            var split = term.split(':');
            window.input[split[0]] = split.slice(1, split.length).join(":");
            window.search[split[0]] = function(key, data, input) {
                return (data + "").indexOf(input) > -1;
            }
        }
        else {
            window.input[''] = term;
            window.search[""] = function(key, data, input) {
                console.log((data + "") + " | " + (input))
                return (data + "").indexOf(input) > -1;
            }
        }
    }
    
    result.innerHTML = "<table id=resulttable><tr><td><h3>Category</h3></td><td><h3>Id</h3></td><td><h3>Creator</h3></td><td><h3>Info</h3></td><td><h3>View</h3></td><td><h3><a href='javascript:add()'>Add</a>/<a href='javascript:remove()'>Remove</a></h3></td></table>";
	
	window.table = document.getElementById("resulttable");
    
    // window.json - The data
    for (var i in window.json) {
        var file = window.json[i];
        setTimeout(function(file) {
            var split = file.split(new RegExp("\\\\|/", 'g'));
            var name = split[split.length - 1].split(".");
            var path = split.slice(1,split.length - 1).join("/");
            var id = name[name.length - 2].replace("_",".");
            if ('' in window.search) {
                if (!window.search[''].call(this, '', path, window.input[''])) {
                    return;
                }
            }
            $.get(file, function(data){
                var json = JSON.parse(data);
                var contains = true;
                for (var tag in json) {
                    var method = window.search[tag];
                    if (method != undefined) {
                        if (!method.call(this, tag, json[tag], window.input[tag])) {
                            contains = false;
                            break;
                        }
                    }
                }
                if (contains) {
                    console.log(file + " : " + name + " | " + path + " -> " + id)
                    var row = window.table.insertRow(-1);
                    row.id = file;
                    row.insertCell(0).innerHTML = path;
                    row.insertCell(1).innerHTML = id;
                    row.insertCell(2).innerHTML = json["creator"];
                    var info = row.insertCell(3);
                    info.innerHTML = "<a tooltip='t' href='javascript:void(0)'>Info</a>"; 
                    info.firstChild.setAttribute("tooltip", data);
                    
                    var viewId = "view" + id;
                    var url = "http://cubical.xyz?url=http://empcraft.com/assetpack/" + file.substring(0, file.length - 4) + "schematic";
                    
                    row.insertCell(4).innerHTML = "<a id=\"" + viewId + "\" href='" + url + "' onclick='return load(this)'>View</a>";
                    var toggle = row.insertCell(5);
                    for (var j in files) {
                        console.log(files[j] + " | " + j + " | " + (j === file + "") + " | " + (file in files));
                    }
                    toggle.innerHTML = "<a id='" + id + "' href=\"javascript:toggle('" + id + "','" + file + "')\">" + ((id in files) ? "Remove" : "Add") + "</a>";
                }
            });
        }, i * 5, file);
    }
    return false;
}
</script>
<style>
td, plaintext {
    -webkit-animation: fadein 1s; /* Safari, Chrome and Opera > 12.1 */
       -moz-animation: fadein 1s; /* Firefox < 16 */
        -ms-animation: fadein 1s; /* Internet Explorer */
         -o-animation: fadein 1s; /* Opera < 12.1 */
            animation: fadein 1s;
}

@keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Firefox < 16 */
@-moz-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Safari, Chrome and Opera > 12.1 */
@-webkit-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Internet Explorer */
@-ms-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Opera < 12.1 */
@-o-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}
</style>
</BODY>
</HTML>