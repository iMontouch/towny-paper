<?php
$file_path  = 'downloads/' . basename($_SERVER['REMOTE_ADDR']) . '.zip';
//ignore_user_abort(true);
//header("Content-type: application/zip");
//header("Content-Disposition: attachment; filename=\"assets.zip\"");
//header("Pragma: no-cache");
//header("Expires: 0");
//readfile($file_path);
?>
<script>
prompt("Copy to clipboard: Ctrl+C, Enter", "<?php echo "http://empcraft.com/assetpack/" . $file_path; ?>");
document.location.href = "http://empcraft.com/assetpack/";
</script>