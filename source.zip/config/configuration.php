<?php

class Config {
    private static $info = array();
    public static function set($key, $value) {
        self::$info[$key] = $value;
    }
    public static function get($key) {
        return self::$info[$key];
    }
    public static function getAll() {
        return self::$info;
    }
}

$styles = array("8bit", "clean", "default", "frame", "gray", "green", "orange", "phanaticd", "shadow");

########################################################################################################################
$config = array();                                                                                                     #
                                                                                                                       #
//DO NOT EDIT ABOVE THIS                                                                                               #
                                                                                                                       #
# Edit below this ######################################################################################################
// The page title                                                                                                      #
$config['title'] = 'Asset Pack'                                           ;                                            #
// The style to use (styles listed above)                                                                              #
$config['style'] = 'clean'                                                ;                                            #
                                                                                                                       #
# e.g. array('192.168.1.10')                                                                                           #
$config['ups']   = array()                                                ; # To authorize all servers use array()     #
                                                                                                                       #
$config['size']  = 15000000                                               ; # Max file size                            #
                                                                                                                       #
// The home button link                                                                                                #
$config['home'] = 'https://www.spigotmc.org/resources/13932/'             ; # Home page                                #
########################################################################################################################

// DO NOT EDIT BELOW THIS
foreach($config as $var => $val) {
    Config::set($var, $val);
}
unset($config);
?>