<?php
echo "fetching from git is disabled for now";
//ini_set('display_errors', 1); error_reporting(E_ALL); 
//ini_set("allow_url_fopen", '1');
//ini_set('user_agent', "PHP\r\nX-MyCustomHeader: Foo");
//$data = $data = file_get_contents("https://github.com/AthionOfficial/Lente-Athion-Resource-Kit/archive/master.zip");
//$path = "src.zip";
//if (file_exists($path) && !unlink($path)) {
//    exit("FAILED!");
//}
//
//$file = fopen($path, "w") or die("Unable to open file!");
//fwrite($file, $data);
//fclose($file);
//
//$zip = new ZipArchive;
//if ($zip->open($path) === TRUE) {
//    $zip->extractTo('tmp');
//    $zip->close();
//    echo 'ok';
//} else {
//    echo 'failed';
//}
//function remove($dir) {
//    if (!file_exists($dir)) {
//        return;
//    }
//    $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
//    $files = new RecursiveIteratorIterator($it,
//                 RecursiveIteratorIterator::CHILD_FIRST);
//    foreach($files as $file) {
//        if ($file->isDir()){
//            rmdir($file->getRealPath());
//        } else {
//            unlink($file->getRealPath());
//        }
//    }
//    rmdir($dir);
//}
//remove('assets');
//rename('tmp/Lente-Athion-Resource-Kit-master', 'assets');
//unlink($path);
//remove('tmp');
?> 