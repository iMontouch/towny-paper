<?php
require "config/configuration.php";

$ips = $schematic_settings = Config::get('required_ips');
if (count($ips) > 0 && !in_array($_SERVER['REMOTE_ADDR'], $ips)) {
    header('Location: http://13.13.13.13');
    exit();
}
if (sizeof($_FILES) == 0) {
  echo "Sorry, only .schematic files are allowed.";
  exit;
}
function guidv4($data) {
    assert(strlen($data) == 16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}
function normalizePath($path)
{
    $parts = array();// Array to build a new path from the good parts
    $path = str_replace('\\', '/', $path);// Replace backslashes with forwardslashes
    $path = preg_replace('/\/+/', '/', $path);// Combine multiple slashes into a single slash
    $segments = explode('/', $path);// Collect path segments
    $test = '';// Initialize testing variable
    foreach($segments as $segment)
    {
        if($segment != '.')
        {
            $test = array_pop($parts);
            if(is_null($test))
                $parts[] = $segment;
            else if($segment == '..')
            {
                if($test == '..')
                    $parts[] = $test;

                if($test == '..' || $test == '')
                    $parts[] = $segment;
            }
            else
            {
                $parts[] = $test;
                $parts[] = $segment;
            }
        }
    }
    return implode('/', $parts);
}
function isBelowAllowedPath($allowedPath, $pathToCheck) {
    return strpos(
        normalizePath($allowedPath . DIRECTORY_SEPARATOR . $pathToCheck), 
        normalizePath($allowedPath)
    ) === 0;
}
$randUID = guidv4(openssl_random_pseudo_bytes(16));
$target_dir = "assets/" . str_replace(".", "/", $_FILES["schematicFile"]["name"]);
$target_file = $target_dir . "/" . $randUID . ".schematic";
$info_file = $target_dir . "/" . $randUID . ".info";
$uploadOk = 1;
// Check path down
if (!isBelowAllowedPath("assets", $target_dir)) {
    echo "Sorry, path is outside allowed folder (" . $target_dir . "). ";
}
// Check if file already
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["schematicFile"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if(strpos($target_dir,'../') !== false){
    echo basename( $_FILES["schematicFile"]["name"]);
    echo " --- ";
    echo $schematicFileType;
    echo " --- ";
    echo "Sorry, only .schematic files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $parent = dirname($target_file);
    if (!is_dir($parent)) {
        mkdir($parent, 0777, true);
    }
    if (move_uploaded_file($_FILES["schematicFile"]["tmp_name"], $target_file)) {
		$myfile = fopen($info_file, "w") or die("Unable to open file!");
		fwrite($myfile, $_SERVER['QUERY_STRING']);
		fclose($myfile);
        echo "The file ". $target_file . " has been uploaded.";
    } else {
        var_dump($_FILES);
        echo $target_file . "\n";
        echo $parent . "\n";
        echo $_FILES['schematicFile']['error'];
        echo "<br>";
        echo "FAILURE";
    }
}
?>
