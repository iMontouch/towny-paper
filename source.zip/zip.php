<?php
$data = json_decode($_POST['files']);
$base = realpath('assets');

$zip = new ZipArchive();
$filename = 'downloads/' . basename($_SERVER['REMOTE_ADDR']) . ".zip";

if (file_exists($filename) && !unlink($filename)) {
    exit();
}

if ($zip->open($filename, ZipArchive::CREATE)!==TRUE) {
    exit("cannot open <$filename>\r\n");
}
foreach($data as $file=>$path) {
    if(substr(realpath($path), 0, strlen($base)) != $base) {
        exit(substr(realpath($path), 0, strlen($base)) . ' x ' . $base);
    }
    $dir = dirname($path);
    $name = '';
    $prefix = '';
    $split = explode('.', basename($path));
    for ($i=0;$i<count($split) - 1;$i++) {
        $name = $name . $prefix . $split[$i];
        $prefix = ".";
    }
    $zip->addFile($dir . '/' . $name . '.schematic', $name . '.schematic');
    $zip->addFile($dir . '/' . $name . '.bo3', $name . '.bo3');
}
echo $filename;
?>