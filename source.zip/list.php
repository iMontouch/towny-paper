<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$directory = new \RecursiveDirectoryIterator('assets');
$iterator = new \RecursiveIteratorIterator($directory);
$files = array();
foreach ($iterator as $info) {
    if (preg_match('/^.+\.info$/i', $info->getFilename())) 
    {
        $files[] = $info->getPathname();
    }
}
echo json_encode($files);
?>