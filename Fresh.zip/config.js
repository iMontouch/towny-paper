//Fresh configuration file :)
var config = []; //don't touch it!

// Server status configuration
config["status.enable"] = true; // true - status enabled, false - status disabled
config["status.ip"] = "95.217.40.83"; // server ip address
config["status.port"] = 25565; // server port
